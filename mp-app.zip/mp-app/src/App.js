import React from "react";
import RouteComponent from "./components/routeComponent";
function App() {
  return <RouteComponent />;
}

export default App;