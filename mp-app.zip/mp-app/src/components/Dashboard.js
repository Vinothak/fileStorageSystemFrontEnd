import React, { Component } from 'react';
import NavComp from './Navbar'
import GetAppIcon from '@material-ui/icons/GetApp';
import axios from 'axios';
export default class Dashboard extends Component {
    constructor(props, ...rest) {
        super(props, ...rest);

       this.state={
         
           travel:"",
           food:"",
           total:"",
           dept:"",
           assign:"",
           userDept:null,
           formName:"",
           formRequest:[],
           userDept:null,
            toggle:false,
            users:[],
            backup:[],
            files:[]
       }
 };  

 componentDidMount() {
  
  
  }
 
   travelExpense=(e)=>{
     this.setState({
       travel:e.target.value
     })
   }
   foodExpense=(e)=>{
    this.setState({
      food:e.target.value
    })
  }

  Total=(e)=>{
    this.setState({
      total:e.target.value
    })
  }
  
  formNameChange=(e)=>{
    this.setState({
      formName:e.target.value
    })
  }

  handleSubmit=()=>{
      console.log('submit called');

        var select =document.getElementById('dept');
        var value=select.options[select.selectedIndex].value;
  
        var select2 =document.getElementById('assign');
        var value2=select2.options[select2.selectedIndex].value;
  
        if(value2==null||this.state.travel==""||this.state.food=="" ||this.state.total==""||this.state.formName==""){
          alert('please enter all details');
          return;
      }
        if(value==this.props.Assigneddept){
          alert('cant submit request to same team');
          return;
        }
       
        this.setState({
          dept:value,
          assign:value2
        })

      
  }

  callSelectMethod=()=>{
    var temparr2=[];
    var select =document.getElementById('dept');
    var value=select.options[select.selectedIndex].value;
    temparr2 = this.state.backup.filter(user => user.userDept == value);
    this.setState({
      users:temparr2
    })
  }

getFiles=()=>{
  axios.get(`http://localhost:5000/file/get-files/${this.props.username}`)
  .then((res)=>{
    console.log(res.data);
    if(res.data.length==0){
      alert("no files to show");
    }
    this.setState({
      files:[...res.data],
      toggle:!this.state.toggle
    })
  }).catch((err)=>console.log(err));
}

 uploadFiles = async e => {
  const files = e.target.files
  console.log('files', files)
  const form = new FormData()
  for (let i = 0; i < files.length; i++) {
    form.append('files', files[i], files[i].name)
  }

  try {
    let request = await fetch(`http://localhost:5000/file/add-files/${this.props.username}`, {
      method: 'post',
      body: form,
    })
    const response = await request.json()
    console.log('Response', response)
  } catch (err) {
    alert('Error uploading the files')
    console.log('Error uploading the files', err)
  }
}

handleDownload=(e,itemPath)=>{
  console.log(itemPath)
  fetch(`http://localhost:5000/file/download/${itemPath}`)
  .then(response => {
    response.blob().then(blob => {
      console.log(response);
      console.log(blob);
      let url = window.URL.createObjectURL(blob);
      let a = document.createElement('a');
      //a.href = url;
         window.location.href = response.url;
      a.download = `class.png`;
      a.click();
    }).catch((err)=>{
      console.log('err is ',err)
    });
 
});
}

 
    render() {
        return (
            <>
<NavComp></NavComp>
  
  
 <div style={{textAlign:'center',marginTop:'5px'}}>
 <input style={{backgroundColor:'#81DAF5'}} type="file"
  multiple
  onChange={e=> this.uploadFiles(e)}
  ></input>

 <button  className="view" onClick={this.getFiles}>view Files</button>

 </div>
 
  <div class='files'>
    <h1>Files List</h1>
    {this.state.toggle===false?null:
    this.state.files.map(item=>{
    return <p style={{marginLeft:'20px'}}>{item.path}<GetAppIcon onClick={(e)=>this.handleDownload(e,item.path)}></GetAppIcon></p>
    })
    
    }
  </div>

        </>
        );
    }
  }


