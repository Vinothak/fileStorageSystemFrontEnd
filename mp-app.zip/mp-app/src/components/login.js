import React, { Component } from "react";
import '../app.scss'
import { withRouter } from "react-router-dom";
import axios from 'axios';
class Login extends Component {
  constructor(props){
    super(props);
    this.state = { userName: "", 
    disable: true,
     message: "",
     useremail:"",
     username:"",
     password:"",
     islogged:false,
     users:[]
  }

  this.emailref=React.createRef();
    this.passref=React.createRef();
  };
  componentDidMount() {
     console.log('component did mount called');
      }
    

    loginAction=()=>{
      let pass=this.passref.current.value;
      let email=this.emailref.current.value;
   
       if(!email || !pass ){
         alert('Please fill in all fields');
         return;
      }
       var url='https://strorageapp.herokuapp.com/users/login'
        axios.post(url,{
          email:email,
          password:pass
        })
        .then(res=>{
          //console.log("res is ",res.date);
          console.log("res is ",res);
          if(res.data.msg==="mailid is not valid"){
             this.setState({
               useremail:""
             })
            alert("Enter valid email address !!");
            return;
          }
          if(res.data.msg=="Password do not match"){
            this.setState({
              password:""
            })
            alert("Password is incorrect !!");
            return;
          }
          if(res!=null){
            alert('logged in');
            this.props.handleChange(res.data.username);
            this.setState({
              useremail:"",
              password:"",
              islogged:true
            },()=>this.props.history.push("/dashboard"))
          }
        }).catch(err=>console.log('error is',err));
  
    
      console.log(this.passref.current.value);
      console.log(this.emailref.current.value);
    }
  


  updateName=(e)=>{
        this.setState({
          useremail:e.target.value
        })
      }
      updatePass=(e)=>{
        this.setState({
          password:e.target.value
        })
      }

  render() {
     const name=this.state.useremail;
     const pass=this.state.password

    return(
      <div className='login-style'>

      <div className="header">Login</div>
      <div className="content">

        <div className="form">
          <div className="form-group">
    
            <input value={name} onChange={this.updateName} type="text" 
            name="email" 
            ref={this.emailref} placeholder="mail address" />
          </div>
          <div className="form-group">
          <input value={pass} type="password"  onChange={this.updatePass}
           name="password" ref={this.passref} placeholder="password" />
          </div> 
        </div>
      </div>
      <div className="footer">
      {this.props.islogged}
      
        <button style={{color:"white"}}onClick={this.loginAction}
        type="button" className="btn">
          Login
        </button>
       
      </div>
       
    </div>
    );
  }
}


export default withRouter(Login);
