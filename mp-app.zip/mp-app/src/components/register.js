import React from "react";
import '../app.scss'
import { withRouter } from "react-router-dom";
import axios from 'axios';

class Register extends React.Component {
  constructor(props) {
    super(props);
    this.state={
      username:"",
      useremail:"",
      password:"",
      userDept:"",
      users:[]
    }
    this.emailref=React.createRef();
    this.passref=React.createRef();
    this.usernameref=React.createRef();
  }

  registerfunc=()=>{
console.log('entered register');
   let email=this.emailref.current.value;
   let pass=this.passref.current.value;
   let name=this.usernameref.current.value;

   if(!name || !email || !pass ){
    alert('Please fill in all fields');
    return;
 }
 if(pass.length<6){
  alert("Password should be atleast 6 characters");
  return;
}
  

var url='http://localhost:5000/users/register'
      axios.post(url,{
        name:name,
        email,
        password:pass
      })
      .then(res=>{
        //console.log("res is ",res.date);
        console.log("res is ",res);
        if(res.data.status==="Failed"){
           this.setState({
             useremail:""
           })
          alert("email id already exists !!")
          return;
        }
        if(res!=null){
          alert('successfully registered');
          var obj={
            username:name,
            password:pass,
            email:email
          };
          var arr=[...this.state.users];
           arr.push(obj);
          this.setState({
            users:arr,
            username:"",
            password:"",
            useremail:""
          })
        }
      }).catch(err=>console.log('error is',err));
  }



  updateEmail=(e)=>{
    this.setState({
      useremail:e.target.value
    })
  }
  updateName=(e)=>{
        this.setState({
          username:e.target.value
        })
      }
      updatePass=(e)=>{
        this.setState({
          password:e.target.value
        })
      }

  render() {

    const name=this.state.username;
    const email=this.state.useremail;
    const password=this.state.password;

    return (
      <div className="base-container" ref={this.props.containerRef}>
        <div className="header">Register</div>
        <div className="content">
          <div className="image">
          </div>
          <div className="form">
            <div className="form-group">
              <label  style={{marginLeft:'25px'}} htmlFor="username">Username :</label>
              <input style={{marginLeft:"15px"}}value={name}  onChange={this.updateName}
               type="text" ref={this.usernameref} name="username" placeholder="username" />
            </div>
 
            <div className="form-group">
              <label style={{marginLeft:'25px'}}htmlFor="email">Email :</label>
              <input style={{marginLeft:"55px"}}value={email} type="text"  onChange={this.updateEmail}
              ref={this.emailref} name="email" placeholder="email" />
            </div>
            <div className="form-group">
              <label style={{marginLeft:'25px'}} htmlFor="password">Password :</label>
              <input style={{marginLeft:"30px"}} type="text" value={password}  onChange={this.updatePass}
              ref={this.passref} name="password" placeholder="password" />
            </div>
          </div>
        </div>
        <div className="footer">
          <button style={{color:"white",backgroundColor:"grey"}}
           onClick={this.registerfunc} type="button" className="btn">
            Register
          </button>
        </div>
      </div>
    );
  }
}
export default withRouter(Register);

