import React, { Component } from 'react';
import { BrowserRouter as Router, Switch, Route,Redirect,Prompt} from "react-router-dom";
import Register from "./register";
import "../index.css";
import Home from './home'
import Dashboard from './Dashboard'
import '../app.scss';
import Logout from './logout';


export default class RouteComponent extends Component {
   constructor(props, ...rest) {
     super(props, ...rest);
     this.state = {
        username:null,
        userDept:null,
        loggedIn:false
    };
  
   }

   callhome=(name)=>{

     this.setState({
       username:name,
       loggedIn:true
     })
     
   }

  render(){
  return (
    <Router>
      <Switch>
        <Route exact path="/">
          <Home callhome={this.callhome}></Home>
        </Route>
        <Route exact path="/register">
          <Register username={this.state.username} dept={this.state.userDept} />
        </Route>
        <Route exact path="/dashboard" strict render={()=>(
           this.state.loggedIn ? (<Dashboard username={this.state.username}
            /> ):(<Redirect to="/"/>)
        )}/>
        <Route exact path="/logout">
          <Logout username={this.state.username} />
        </Route>
      </Switch>
      <Prompt 
      when={this.state.loggedIn}
      message={(location)=>{
        return location.pathname.startsWith('/logout')?'Are you sure?':true
      }}
      />
    </Router>
  );
}}

